import Foundation

// Concurrency -> is keep UI Responsive manage task with background | store as data validate
func fetchData() async -> String{
    return "data loaded"
}

Task{
    let a = await fetchData()
    print(a)
}

Task(priority: .high){
    print("Priority high")
}
