import Foundation
import math_h

// Review : Concurrency in swift
let dispath = DispatchGroup() // create a dispathGroup
for i in 1...4{
    print("Item on Thread : \(i)");
    print("Thread is Iniatialize !\(Thread.current)");
    
    // networking result of Thread
    sleep(300)
    
    dispath.wait() // waiting the thread
    
}

dispath.leave() // leaving the thread
dispatchMain() //  run the programing on thread
print("All result is completed...!")
// Review on the Memory leak

// Strong reference cycle

class Teacher{
    var name : String
    var major : Student?
    
    // constructor
    init(name: String, major: Student? = nil) {
        self.name = name
        self.major = major
    }
    // calling deallocated
    deinit{
        print("\(name) id deallocated...!")
    }
}

class Student{
    // closure call
    var unit : String
    var tenant : Teacher?
    
    init(unit: String) {
        self.unit = unit
    }
    
    deinit{
        print("Student \(unit) is on Reference cycle...!");
    }
}

// create object
var virak : Teacher? = Teacher(name: "Un virak")
var apt : Student? = Student(unit: "Mobile App development")

virak?.major = apt
apt?.tenant = virak

// memory leak on nil
virak = nil
apt = nil

